<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Post_model extends CI_Model {
    
    public function get_posts($category_id = null) {
        $this->db->select('posts.*');
        $this->db->from('posts');
        $this->db->join('categories','categories.id = posts.category_id','right');
        if ($category_id) {
            $this->db->where('posts.category_id', $category_id);
        }
        $query = $this->db->get();
        // echo $this->db->last_query(); die;
        return $query->result();
    }

    public function get_post($id) {
        $this->db->where('id', $id);
        $query = $this->db->get('posts');
        return $query->row(); 
    }

    public function create_post($data) {
        return $this->db->insert('posts', $data);
    }

    public function update_post($id, $data) {
        $this->db->where('id', $id);
        return $this->db->update('posts', $data);
    }

    public function delete_post($id) {
        return $this->db->delete('posts', array('id' => $id));
    }
}
