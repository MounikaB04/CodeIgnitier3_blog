<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Comments</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background-color: #f4f4f4;
            margin: 0;
            padding: 0;
        }
        .container {
            max-width: 800px;
            margin: 50px auto;
            background-color: white;
            padding: 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.1);
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-bottom: 20px;
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: left;
        }
        th {
            background-color: black ;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        .back-button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #007bff;
            color: white;
            text-align: center;
            border-radius: 4px;
            text-decoration: none;
            transition: background-color 0.3s;
        }
        .back-button:hover {
            background-color: #0056b3;
        }
        .delete-button {
            display: inline-block;
            padding: 10px 15px;
            background-color: #b30300;
            color: white;
            text-align: center;
            border-radius: 4px;
            text-decoration: none;
            border: none;
            cursor: pointer;
            transition: background-color 0.3s;
        }
        .delete-button:hover {
            background-color: #8a0200;
        }
    </style>
</head>
<body>
    <?php include 'application/views/common/navbar.php'; ?>
    <div class="container">
        <h1>Manage Comments</h1>
        <table>
            <tr>
                <th>ID</th>
                <th>Post ID</th>
                <th>User ID</th>
                <th>Comments</th>
                <th>Action</th>
            </tr>
            <?php foreach ($comments as $comment): ?>
            <tr>
                <td><?= $comment['id'] ?></td>
                <td><?= $comment['post_id'] ?></td>
                <td><?= $comment['user_id'] ?></td>
                <td><?= $comment['comment'] ?></td>
                <td>
                    <a href="<?= site_url('admin/delete_comment/'.$comment['id']) ?>" onclick="return confirm('Are you sure?')">
                        <button class="delete-button">Delete</button>
                    </a>
                </td>
            </tr>
            <?php endforeach; ?>
        </table>
        <a href="dashboard" class="back-button">Back to Dashboard</a>
    </div>
</body>
</html>
