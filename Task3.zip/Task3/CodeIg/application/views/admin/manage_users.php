<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Manage Users</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            background-color: #f0f0f0;
            margin: 0;
            padding: 20px;
        }
        h1 {
            text-align: center;
            color: #333;
            margin-bottom: 20px;
        }
        .container {
            max-width: 800px;
            margin: 0 auto;
            background-color: white;
            border-radius: 8px;
            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
            padding: 20px;
            margin-top: 40px;
        }
        .create-user {
            margin-bottom: 20px;
            text-align: right;
        }
        .create-user a {
            background-color: #007bff;
            color: white;
            padding: 10px 15px;
            text-decoration: none;
            border-radius: 4px;
            transition: background-color 0.3s ease;
        }
        .create-user a:hover {
            background-color: #0056b3;
            color: black;
        }
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 10px;
        }
        th, td {
            padding: 10px;
            text-align: left;
            border: 1px solid #ddd;
        }
        th {
            background-color: black;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f9f9f9;
        }
        tr:hover {
            background-color: #f1f1f1;
        }
        a {
            color: #007bff;
            text-decoration: none;
            transition: color 0.3s ease;
        }
        a:hover {
            color: #0056b3;
        }
        button {
            background-color: #00b35d;
            color: white;
            font-size: 1em;
            border: none;
            border-radius: 4px;
            padding: 10px 15px;
            cursor: pointer;
            transition: background-color 0.3s ease, transform 0.2s;
        }
        button:hover {
            background-color: #008f4e;
            transform: translateY(-2px);
        }
        .delete-button {
            background-color: #b30300;
        }
        .delete-button:hover {
            background-color: #960000;
        }
        .back-button {
            background-color: #007bff;
            color: white;
            padding: 10px 20px;
            border: none;
            border-radius: 4px;
            font-size: 1.2em;
            transition: background-color 0.3s ease, transform 0.2s;
            text-decoration: none;
            display: inline-block;
            margin-top: 20px;
        }
        .back-button:hover {
            background-color: grey;
            color: black;
            transform: translateY(-2px);
        }
    </style>
</head>
<body>
    <?php include 'application/views/common/navbar.php'; ?>
    <div class="container">
        <h1>Manage Users</h1>
        <!-- <div class="create-user">
            <a href="<?= site_url('admin/create_user') ?>">Create User</a>
        </div> -->
        <table>
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Profile</th>
                    <th>Username</th>
                    <th>Role</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($users as $user): ?>
                    <?php if ($user->role === 'user'): ?>
                        <tr>
                            <td><?= $user->id ?></td>
                            <td>
                                <img src="<?= base_url('uploads/').$user->profile ?>" style="width: 100px; height: 100px; object-fit: cover;" alt="User Profile Picture">
                            </td>
                            <td><?= $user->username ?></td>
                            <td><?= $user->role ?></td>
                            <td>
                                <a href="<?= site_url('admin/edit_user/' . $user->id) ?>"><button>Edit</button></a>&nbsp;
                                <a href="<?= site_url('admin/delete_user/' . $user->id) ?>" onclick="return confirm('Are you sure?')"><button class="delete-button">Delete</button></a>
                            </td>
                        </tr>
                    <?php endif; ?>
                <?php endforeach; ?>
            </tbody>
        </table>
        <br>
        <a href="dashboard" class="back-button">Back to Dashboard</a>
    </div>
</body>
</html>
