<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Admin Dashboard</title>
    <style>
        body {
            font-family: 'Arial', sans-serif;
            background: linear-gradient(to right, #a7c7e7, #e3f2fd);
            margin: 0;
            padding: 20px;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            color: #333;
        }
        h1 {
            text-align: center;
            font-size: 2.5em;
            text-transform: uppercase;
            margin-bottom: 40px;
            background-color: #007bff;
            color: white;
            padding: 15px 20px;
            border-radius: 8px;
            box-shadow: 0 4px 10px rgba(0, 0, 0, 0.3);
            width: 100%;
            max-width: 600px;
        }
        .dashboard-container {
            max-width: 500px;
            width: 100%;
            background-color: white;
            border-radius: 12px;
            box-shadow: 0 8px 20px rgba(0, 0, 0, 0.15);
            padding: 30px;
            animation: fadeIn 0.5s ease;
        }
        @keyframes fadeIn {
            from { opacity: 0; transform: translateY(-20px); }
            to { opacity: 1; transform: translateY(0); }
        }
        ul {
            list-style-type: none;
            padding: 0;
        }
        li {
            margin: 15px 0;
            border-radius: 6px;
            overflow: hidden;
        }
        a {
            display: block;
            background-color: grey;
            color: white;
            text-decoration: none;
            padding: 15px;
            text-align: center;
            font-size: 1.1em;
            border-radius: 6px;
            transition: background-color 0.3s ease, transform 0.2s;
        }
        a:hover {
            background-color: #0056b3;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(0, 86, 179, 0.2);
        }
        .logout {
            text-align: center;
            margin-top: 25px;
        }
        .logout a {
            background-color: #dc3545;
            padding: 12px 20px;
            border-radius: 6px;
            color: white;
            text-decoration: none;
            font-weight: bold;
            transition: background-color 0.3s ease, transform 0.2s;
        }
        .logout a:hover {
            background-color: #c82333;
            transform: translateY(-2px);
            box-shadow: 0 4px 10px rgba(220, 53, 69, 0.2);
        }
    </style>
</head>
<body>

    <h1>Admin Dashboard</h1>
    <div class="dashboard-container">
        <ul>
            <li><a href="<?= site_url('admin/manage_users') ?>">Manage Users</a></li>
            <li><a href="<?= site_url('admin/manage_posts') ?>">Manage Posts</a></li>
            <li><a href="<?= site_url('admin/manage_categories') ?>">Manage Categories</a></li>
            <li><a href="<?= site_url('admin/manage_comments') ?>">Manage Comments</a></li>
        </ul>
        <div class="logout">
            <a href="<?= site_url('auth/logout') ?>">Logout</a>
        </div>
    </div>
</body>
</html>
