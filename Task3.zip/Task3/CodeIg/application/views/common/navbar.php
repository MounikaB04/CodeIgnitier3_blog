<nav style="background-color: #6c757d; padding: 15px; box-shadow: 0 2px 10px rgba(0, 0, 0, 0.2); position: fixed; top: 0; left: 0; width: 100%; z-index: 1000;">
    <ul style="display: flex; justify-content: flex-end; list-style: none; padding: 0; margin: 0;">
        <li style="margin: 0 15px; position: relative;">
            <a href="<?= site_url('admin/manage_users') ?>" style="color: white; text-decoration: none; padding: 8px 12px; font-weight: bold; position: relative; transition: color 0.3s;">
                Manage Users
            </a>
            <span class="underline"></span>
        </li>
        <li style="margin: 0 15px; position: relative;">
            <a href="<?= site_url('admin/manage_posts') ?>" style="color: white; text-decoration: none; padding: 8px 12px; font-weight: bold; position: relative; transition: color 0.3s;">
                Manage Posts
            </a>
            <span class="underline"></span>
        </li>
        <li style="margin: 0 15px; position: relative;">
            <a href="<?= site_url('admin/manage_categories') ?>" style="color: white; text-decoration: none; padding: 8px 12px; font-weight: bold; position: relative; transition: color 0.3s;">
                Manage Categories
            </a>
            <span class="underline"></span>
        </li>
        <li style="margin: 0 15px; position: relative;">
            <a href="<?= site_url('admin/manage_comments') ?>" style="color: white; text-decoration: none; padding: 8px 12px; font-weight: bold; position: relative; transition: color 0.3s;">
                Manage Comments
            </a>
            <span class="underline"></span>
        </li>

        <li style="margin: 0 15px; position: relative;">
            <a href="<?= site_url('auth/logout') ?>" style="color: #dc3545; text-decoration: none; padding: 8px 12px; font-weight: bold; position: relative; transition: color 0.3s;">
                Logout
            </a>
            <span class="underline" style="background-color: #dc3545;"></span>
        </li>
    </ul>
</nav>

<style>
    body {
        margin: 0;
        padding-top: 70px; /* Adjust based on navbar height */
    }

    nav ul li a:hover {
        color: #ffeb3b;
    }

    nav ul li a {
        font-family: Arial, sans-serif;
        font-size: 1.1em;
        display: inline-block;
        border-radius: 5px;
    }

    .underline {
        position: absolute;
        bottom: 0;
        left: 50%;
        width: 0;
        height: 2px;
        background-color: #ffeb3b;
        transition: width 0.3s ease, left 0.3s ease;
    }

    nav ul li a:hover + .underline {
        width: 100%;
        left: 0;
    }
</style>
